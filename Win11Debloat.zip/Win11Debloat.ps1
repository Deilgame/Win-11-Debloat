﻿#Requires -Version 5.1
# =====================================================================
#  Win11 Debloat — отключение лишних служб/процессов/телеметрии
#  НЕ трогает: Defender, Брандмауэр, Центр безопасности, SmartScreen,
#  Windows Update и всё, без чего Windows не загрузится.
# =====================================================================
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# --- Автоповышение до администратора ---------------------------------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`""
    exit
}

$BackupDir  = Join-Path $env:ProgramData 'Win11Debloat'
$BackupFile = Join-Path $BackupDir 'services_backup.json'
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null }

# --- Вспомогательные функции -----------------------------------------
# База изменений: для каждого твика запоминаем исходное состояние,
# чтобы потом можно было всё вернуть обратно.
$DBFile = Join-Path $BackupDir 'backup.clixml'
$script:DB = @{}
$script:CurTweak = $null
if (Test-Path $DBFile) { try { $script:DB = Import-Clixml -Path $DBFile } catch { $script:DB = @{} } }
if ($script:DB -isnot [hashtable]) { $script:DB = @{} }

function Save-DB { try { $script:DB | Export-Clixml -Path $DBFile -Depth 8 } catch { } }

function Log($m) {
    $script:LogBox.AppendText(("[{0}] {1}`r`n" -f (Get-Date -Format 'HH:mm:ss'), $m))
    [System.Windows.Forms.Application]::DoEvents()
}

function Get-Rec([string]$title) {
    if (-not $script:DB.ContainsKey($title)) {
        $script:DB[$title] = @{ svc = @{}; reg = @(); tasks = @(); apps = @() }
    }
    return $script:DB[$title]
}

# --- Реестр ---
function Record-Reg($path, $name) {
    $rec = Get-Rec $script:CurTweak
    foreach ($x in @($rec.reg)) { if ($x -and $x.p -eq $path -and $x.n -eq $name) { return } }
    $e = @{ p = $path; n = $name; existed = $false; v = $null; t = $null }
    try {
        $item = Get-Item -Path $path -ErrorAction Stop
        $val = $item.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        if ($null -ne $val) { $e.existed = $true; $e.v = $val; $e.t = $item.GetValueKind($name).ToString() }
    } catch { }
    $rec['reg'] = @($rec['reg']) + @(, $e)
}

function Set-Reg($path, $name, $value, $type = 'DWord') {
    try {
        if ($script:CurTweak) { Record-Reg $path $name }
        if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
        New-ItemProperty -Path $path -Name $name -Value $value -PropertyType $type -Force -ErrorAction Stop | Out-Null
    } catch { Log "  реестр: не удалось $path\$name ($($_.Exception.Message))" }
}

function Restore-Reg($e) {
    try {
        if ($e.existed) {
            if (-not (Test-Path $e.p)) { New-Item -Path $e.p -Force | Out-Null }
            $pt = 'String'
            if (@('DWord', 'String', 'QWord', 'ExpandString', 'MultiString', 'Binary') -contains $e.t) { $pt = $e.t }
            New-ItemProperty -Path $e.p -Name $e.n -Value $e.v -PropertyType $pt -Force -ErrorAction Stop | Out-Null
        } else {
            Remove-ItemProperty -Path $e.p -Name $e.n -ErrorAction SilentlyContinue
        }
    } catch { Log "  реестр: не удалось вернуть $($e.p)\$($e.n)" }
}

# --- Службы ---
function Disable-Svc([string[]]$names) {
    foreach ($n in $names) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if (-not $svc) { continue }
        if ($script:CurTweak) {
            $rec = Get-Rec $script:CurTweak
            if (-not $rec.svc.ContainsKey($n)) { $rec.svc[$n] = (Get-CimInstance Win32_Service -Filter "Name='$n'").StartMode }
        }
        try {
            Stop-Service -Name $n -Force -ErrorAction SilentlyContinue
            Set-Service -Name $n -StartupType Disabled -ErrorAction Stop
            Log "  служба отключена: $n"
        } catch {
            & sc.exe config $n start= disabled | Out-Null
            Log "  служба (sc): $n"
        }
    }
}

function Restore-Svc($n, $mode) {
    $map = @{ 'Auto' = 'Automatic'; 'Manual' = 'Manual'; 'Disabled' = 'Disabled'; 'Boot' = 'Automatic'; 'System' = 'Automatic' }
    $m = $map[[string]$mode]; if (-not $m) { $m = 'Manual' }
    try {
        Set-Service -Name $n -StartupType $m -ErrorAction Stop
        if ($m -eq 'Automatic') { Start-Service -Name $n -ErrorAction SilentlyContinue }
        Log "  служба включена: $n ($m)"
    } catch {
        $sc = 'demand'; if ($m -eq 'Automatic') { $sc = 'auto' } elseif ($m -eq 'Disabled') { $sc = 'disabled' }
        & sc.exe config $n start= $sc | Out-Null
        Log "  служба (sc): $n -> $sc"
    }
}

# --- Задачи планировщика ---
function Disable-Tasks([string[]]$tasks) {
    foreach ($t in $tasks) {
        $i = $t.LastIndexOf('\')
        $path = $t.Substring(0, $i + 1); $name = $t.Substring($i + 1)
        $task = Get-ScheduledTask -TaskPath $path -TaskName $name -ErrorAction SilentlyContinue
        if ($task) {
            if ($script:CurTweak -and $task.State -ne 'Disabled') {
                $rec = Get-Rec $script:CurTweak
                if (@($rec.tasks) -notcontains $t) { $rec['tasks'] = @($rec['tasks']) + $t }
            }
            Disable-ScheduledTask -TaskPath $path -TaskName $name -ErrorAction SilentlyContinue | Out-Null
            Log "  задача отключена: $name"
        }
    }
}

# --- Приложения ---
function Remove-Apps([string[]]$patterns) {
    foreach ($p in $patterns) {
        foreach ($pkg in @(Get-AppxPackage -AllUsers -Name $p -ErrorAction SilentlyContinue)) {
            Log "  удаляю: $($pkg.Name)"
            if ($script:CurTweak) {
                $rec = Get-Rec $script:CurTweak
                $rec['apps'] = @($rec['apps']) + @(, @{ n = $pkg.Name; loc = $pkg.InstallLocation })
            }
            Remove-AppxPackage -Package $pkg.PackageFullName -AllUsers -ErrorAction SilentlyContinue
        }
        Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like $p } |
            ForEach-Object { Remove-AppxProvisionedPackage -Online -PackageName $_.PackageName -ErrorAction SilentlyContinue | Out-Null }
    }
}

function Stop-Procs([string[]]$names) {
    foreach ($n in $names) { Get-Process -Name $n -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue }
}

function New-RestorePoint {
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' 'SystemRestorePointCreationFrequency' 0
        Checkpoint-Computer -Description 'Win11 Debloat' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Log 'Точка восстановления создана.'
    } catch { Log "Точка восстановления не создана: $($_.Exception.Message)" }
}

# --- Возврат изменений ---
function Revert-Title([string]$title) {
    if (-not $script:DB.ContainsKey($title)) {
        Log '  нет записей об изменениях (этот твик не применялся программой)'
        return
    }
    $rec = $script:DB[$title]
    foreach ($k in @($rec.svc.Keys)) { Restore-Svc $k $rec.svc[$k] }
    foreach ($e in @($rec.reg)) { if ($e) { Restore-Reg $e } }
    foreach ($tk in @($rec.tasks)) {
        $p = [string]$tk; $i = $p.LastIndexOf('\')
        Enable-ScheduledTask -TaskPath $p.Substring(0, $i + 1) -TaskName $p.Substring($i + 1) -ErrorAction SilentlyContinue | Out-Null
        Log "  задача включена: $($p.Substring($i + 1))"
    }
    foreach ($a in @($rec.apps)) {
        if (-not $a) { continue }
        $mf = if ($a.loc) { Join-Path $a.loc 'AppxManifest.xml' } else { '' }
        if ($mf -and (Test-Path $mf)) {
            try { Add-AppxPackage -DisableDevelopmentMode -Register $mf -ErrorAction Stop; Log "  приложение возвращено: $($a.n)" }
            catch { Log "  не удалось вернуть: $($a.n)" }
        } else {
            Log "  $($a.n): файлы удалены, установите из Microsoft Store"
        }
    }
    $tw = $Tweaks | Where-Object { $_.Title -eq $title } | Select-Object -First 1
    if ($tw -and $tw.Revert) { try { & $tw.Revert } catch { Log "  ошибка: $($_.Exception.Message)" } }
    $script:DB.Remove($title)
    Save-DB
}

# Совместимость со старой версией (services_backup.json)
function Revert-Legacy {
    $old = Join-Path $BackupDir 'services_backup.json'
    if (-not (Test-Path $old)) { return }
    $raw = Get-Content $old -Raw -ErrorAction SilentlyContinue
    if ($raw) {
        $obj = $raw | ConvertFrom-Json
        if ($obj) { foreach ($p in $obj.PSObject.Properties) { Restore-Svc $p.Name $p.Value } }
    }
    Move-Item $old ($old + '.restored') -Force -ErrorAction SilentlyContinue
}

# --- Список твиков ----------------------------------------------------
$Tweaks = New-Object System.Collections.ArrayList
function T($group, $title, $default, $desc, [scriptblock]$run, [scriptblock]$revert = $null) {
    [void]$Tweaks.Add([pscustomobject]@{ Group = $group; Title = $title; Default = $default; Desc = $desc; Run = $run; Revert = $revert })
}

# ===== ТЕЛЕМЕТРИЯ =====
$G = 'Телеметрия и слежка'
T $G 'Службы телеметрии (DiagTrack, dmwappushservice)' $true 'Connected User Experiences and Telemetry' {
    Disable-Svc 'DiagTrack', 'dmwappushservice'
}
T $G 'Политики телеметрии (AllowTelemetry=0, фидбек, CEIP)' $true 'Реестр: минимальный уровень диагностики, отключение отзывов' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry' 0
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' 'AllowTelemetry' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'DoNotShowFeedbackNotifications' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' 'CEIPEnable' 0
    Set-Reg 'HKCU:\Software\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' 'AITEnable' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' 'DisableInventory' 1
}
T $G 'Задачи планировщика телеметрии (Appraiser, CEIP и т.д.)' $true 'Отключает сборщики данных в Task Scheduler' {
    Disable-Tasks @(
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
        '\Microsoft\Windows\Application Experience\StartupAppTask',
        '\Microsoft\Windows\Application Experience\PcaPatchDbTask',
        '\Microsoft\Windows\Autochk\Proxy',
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
        '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip',
        '\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask',
        '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector',
        '\Microsoft\Windows\Feedback\Siuf\DmClient',
        '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload',
        '\Microsoft\Windows\Windows Error Reporting\QueueReporting',
        '\Microsoft\Windows\Maps\MapsToastTask',
        '\Microsoft\Windows\Maps\MapsUpdateTask',
        '\Microsoft\XblGameSave\XblGameSaveTask'
    )
}
T $G 'Отчёты об ошибках (WerSvc)' $true 'Windows Error Reporting' {
    Disable-Svc 'WerSvc', 'wercplsupport'
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' 'Disabled' 1
}
T $G 'Диагностические службы (DPS, WdiServiceHost, WdiSystemHost)' $true 'Диагностика и устранение неполадок' {
    Disable-Svc 'DPS', 'WdiServiceHost', 'WdiSystemHost'
}
T $G 'Рекламный ID, советы, предложения, спонсорский контент' $true 'Реклама в Пуске, на экране блокировки, в уведомлениях' {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0
    $cdm = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
    foreach ($k in 'ContentDeliveryAllowed', 'OemPreInstalledAppsEnabled', 'PreInstalledAppsEnabled', 'PreInstalledAppsEverEnabled',
                   'SilentInstalledAppsEnabled', 'SoftLandingEnabled', 'SystemPaneSuggestionsEnabled', 'RotatingLockScreenOverlayEnabled',
                   'SubscribedContent-310093Enabled', 'SubscribedContent-338387Enabled', 'SubscribedContent-338388Enabled',
                   'SubscribedContent-338389Enabled', 'SubscribedContent-338393Enabled', 'SubscribedContent-353694Enabled',
                   'SubscribedContent-353696Enabled', 'SubscribedContent-353698Enabled', 'SubscribedContent-88000326Enabled') {
        Set-Reg $cdm $k 0
    }
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' 'DisableWindowsConsumerFeatures' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' 'DisableSoftLanding' 1
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'ShowSyncProviderNotifications' 0
}
T $G 'История активности / Timeline' $true 'Не собирать и не отправлять историю действий' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'EnableActivityFeed' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'PublishUserActivities' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'UploadUserActivities' 0
}
T $G 'Геолокация (lfsvc)' $true 'Служба определения местоположения' {
    Disable-Svc 'lfsvc'
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' 'DisableLocation' 1
}
T $G 'Поиск через Bing в меню Пуск и Cortana' $true 'Убирает веб-результаты из поиска' {
    Set-Reg 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' 'AllowCortana' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' 'ConnectedSearchUseWeb' 0
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled' 0
}

# ===== ИИ / ВИДЖЕТЫ =====
$G = 'Copilot, Recall, виджеты'
T $G 'Отключить Copilot' $true 'Политика TurnOffWindowsCopilot' {
    Set-Reg 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot' 1
}
T $G 'Отключить Recall / ИИ-анализ данных' $true 'Политика DisableAIDataAnalysis' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI' 'DisableAIDataAnalysis' 1
}
T $G 'Отключить виджеты и «Новости и интересы»' $true 'Убирает процессы Widgets / WebExperience' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests' 0
    Stop-Procs 'Widgets', 'WidgetService'
    Remove-Apps 'MicrosoftWindows.Client.WebExperience'
}

T $G 'Убрать значок Чата (Teams) с панели задач' $true 'Политика ChatIcon' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Chat' 'ChatIcon' 3
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarMn' 0
}

# ===== ФОНОВЫЕ ПРОЦЕССЫ =====
$G = 'Фоновые процессы и службы'
T $G 'Фоновая работа UWP-приложений' $true 'Запрещает приложениям работать в фоне' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 2
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 1
}
T $G 'Xbox-службы и Game DVR/Game Bar' $true 'XblAuthManager, XblGameSave, XboxGipSvc, XboxNetApiSvc, GamingServices' {
    Disable-Svc 'XblAuthManager', 'XblGameSave', 'XboxGipSvc', 'XboxNetApiSvc', 'GamingServices', 'GamingServicesNet'
    Set-Reg 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowGameDVR' 0
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 0
}
T $G 'Оптимизация доставки (DoSvc)' $true 'P2P-раздача обновлений' {
    Disable-Svc 'DoSvc'
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' 'DODownloadMode' 0
}
T $G 'Мелкие ненужные службы (Fax, Maps, RetailDemo, RemoteRegistry и т.д.)' $true 'Fax, MapsBroker, RetailDemo, WMPNetworkSvc, RemoteRegistry, TrkWks, wisvc, WpcMonSvc, CscService, AJRouter' {
    Disable-Svc 'Fax', 'MapsBroker', 'RetailDemo', 'WMPNetworkSvc', 'RemoteRegistry', 'TrkWks', 'wisvc', 'WpcMonSvc', 'CscService', 'AJRouter'
}
T $G 'NFC-платежи и кошелёк Windows' $true 'SEMgrSvc, WalletService' {
    Disable-Svc 'SEMgrSvc', 'WalletService'
}
T $G 'Индексация Windows (WSearch)' $true 'Windows Search: отключает индексатор SearchIndexer; поиск файлов станет медленнее, поиск приложений в Пуске работает' {
    Disable-Svc 'WSearch'
    Stop-Procs 'SearchIndexer'
}
T $G 'Служба Помощника по совместимости (PcaSvc)' $true 'Program Compatibility Assistant' {
    Disable-Svc 'PcaSvc'
}

# ===== EDGE / ONEDRIVE =====
$G = 'Edge и OneDrive'
T $G 'Отключить фоновую работу Edge и его автообновление' $true 'Startup Boost, фоновый режим, службы edgeupdate (сам браузер остаётся)' {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'StartupBoostEnabled' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'BackgroundModeEnabled' 0
    Disable-Svc 'edgeupdate', 'edgeupdatem', 'MicrosoftEdgeElevationService'
    Get-ScheduledTask -TaskName 'MicrosoftEdgeUpdate*' -ErrorAction SilentlyContinue | ForEach-Object { Disable-Tasks ($_.TaskPath + $_.TaskName) }
}
T $G 'Удалить OneDrive' $true 'Файлы, синхронизированные в облаке, останутся в папке OneDrive' {
    Stop-Procs 'OneDrive'
    $setup = "$env:SystemRoot\SysWOW64\OneDriveSetup.exe"
    if (-not (Test-Path $setup)) { $setup = "$env:SystemRoot\System32\OneDriveSetup.exe" }
    if (Test-Path $setup) { Start-Process $setup '/uninstall' -Wait; Log '  OneDrive удалён' }
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' 'DisableFileSyncNGSC' 1
} {
    $setup = "$env:SystemRoot\SysWOW64\OneDriveSetup.exe"
    if (-not (Test-Path $setup)) { $setup = "$env:SystemRoot\System32\OneDriveSetup.exe" }
    if (Test-Path $setup) { Start-Process $setup '/silent'; Log '  OneDrive устанавливается заново' }
    else { Log '  OneDriveSetup.exe не найден — скачайте OneDrive с сайта Microsoft' }
}

# ===== ПРИЛОЖЕНИЯ =====
$G = 'Удаление встроенных приложений (Microsoft Store НЕ трогаем)'
T $G 'Новости, Погода, Карты, Помощь, Советы, Feedback Hub, Solitaire, Люди' $true 'BingNews, BingWeather, WindowsMaps, GetHelp, Getstarted, FeedbackHub, Solitaire, People' {
    Remove-Apps 'Microsoft.BingNews', 'Microsoft.BingWeather', 'Microsoft.BingSearch', 'Microsoft.WindowsMaps', 'Microsoft.GetHelp',
                'Microsoft.Getstarted', 'Microsoft.WindowsFeedbackHub', 'Microsoft.MicrosoftSolitaireCollection', 'Microsoft.People',
                'Microsoft.MicrosoftOfficeHub', 'Microsoft.Todos', 'Microsoft.PowerAutomateDesktop', 'Microsoft.OneConnect', 'Microsoft.Wallet'
}
T $G 'Clipchamp, Groove/Фильмы и ТВ, Paint 3D, 3D Viewer, Mixed Reality' $true 'Мультимедийный мусор' {
    Remove-Apps 'Clipchamp.Clipchamp', 'Microsoft.ZuneMusic', 'Microsoft.ZuneVideo', 'Microsoft.MSPaint', 'Microsoft.Microsoft3DViewer', 'Microsoft.MixedReality.Portal'
}
T $G 'Почта и Календарь, Outlook (new), OneNote, Skype, Quick Assist, DevHome' $true 'Офисные/коммуникационные приложения' {
    Remove-Apps 'Microsoft.WindowsCommunicationsApps', 'Microsoft.OutlookForWindows', 'MicrosoftCorporationII.QuickAssist', 'Microsoft.Office.OneNote', 'Microsoft.SkypeApp',
                'Microsoft.Windows.DevHome'
}
T $G 'Teams (встроенный) и Copilot-приложение, Cortana' $true 'MSTeams, MicrosoftTeams, Microsoft.Copilot, Cortana' {
    Stop-Procs 'ms-teams', 'Teams'
    Remove-Apps 'MSTeams', 'MicrosoftTeams', 'Microsoft.Copilot', 'Microsoft.549981C3F5F10'
}
T $G 'Xbox-приложения' $true 'Xbox, Game Bar, Gaming App, Identity Provider' {
    Remove-Apps 'Microsoft.GamingApp', 'Microsoft.XboxApp', 'Microsoft.XboxGameOverlay', 'Microsoft.XboxGamingOverlay',
                'Microsoft.XboxIdentityProvider', 'Microsoft.XboxSpeechToTextOverlay', 'Microsoft.Xbox.TV.App'
}
T $G 'Phone Link (Связь с телефоном / CrossDevice)' $true 'Удаляет приложение и процессы синхронизации с телефоном' {
    Stop-Procs 'PhoneExperienceHost', 'YourPhone'
    Remove-Apps 'Microsoft.YourPhone', 'MicrosoftWindows.CrossDevice'
}
T $G 'Спонсорские приложения (Spotify, TikTok, Netflix, Disney+, Candy Crush…)' $true 'Предустановленная реклама от партнёров' {
    Remove-Apps 'SpotifyAB.SpotifyMusic', '*TikTok*', '*Disney*', '*Facebook*', '*Instagram*', '*Netflix*', '*Twitter*',
                '*LinkedIn*', 'king.com.*', '*Amazon.com.Amazon*', '*PrimeVideo*', '*Duolingo*', '*Hulu*'
}

# --- GUI --------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Win11 Debloat — чистка процессов и ОЗУ'
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Size = New-Object System.Drawing.Size([Math]::Min(780, $wa.Width - 20), [Math]::Min(760, $wa.Height - 20))
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$form.MinimumSize = New-Object System.Drawing.Size(560, 420)

$tip = New-Object System.Windows.Forms.ToolTip
$tip.AutoPopDelay = 15000

# Жёсткая сетка: заголовок / список / кнопки / лог
$tbl = New-Object System.Windows.Forms.TableLayoutPanel
$tbl.Dock = 'Fill'
$tbl.ColumnCount = 1
$tbl.RowCount = 4
[void]$tbl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 64)))
[void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 84)))
[void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 110)))
$form.Controls.Add($tbl)

# Заголовок
$hdr = New-Object System.Windows.Forms.Label
$hdr.Dock = 'Fill'
$hdr.Text = "Отметьте нужные твики. Защита, Windows Update, Wi-Fi, Bluetooth, печать и внешний вид системы не затрагиваются.`r`nНаведите курсор на пункт — будет описание.`r`nРежим «Вернуть обратно» включает выбранное назад (службы, реестр, задачи, приложения)."
$tbl.Controls.Add($hdr, 0, 0)

# Список твиков
$scroll = New-Object System.Windows.Forms.Panel
$scroll.Dock = 'Fill'
$scroll.AutoScroll = $true
$tbl.Controls.Add($scroll, 0, 1)

$checks = New-Object System.Collections.ArrayList
$y = 8; $lastGroup = ''
foreach ($t in $Tweaks) {
    if ($t.Group -ne $lastGroup) {
        $lastGroup = $t.Group
        $y += 6
        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = $t.Group
        $lbl.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
        $lbl.ForeColor = [System.Drawing.Color]::FromArgb(0, 90, 158)
        $lbl.AutoSize = $true
        $lbl.Location = New-Object System.Drawing.Point(10, $y)
        $scroll.Controls.Add($lbl)
        $y += 26
    }
    $cb = New-Object System.Windows.Forms.CheckBox
    $cb.Text = $t.Title
    $cb.Checked = $t.Default
    $cb.Tag = $t
    $cb.Location = New-Object System.Drawing.Point(26, $y)
    $cb.Size = New-Object System.Drawing.Size(700, 22)
    $cb.Anchor = 'Top, Left, Right'
    $tip.SetToolTip($cb, $t.Desc)
    $scroll.Controls.Add($cb)
    [void]$checks.Add($cb)
    $y += 24
}

# Кнопки (ПРИМЕНИТЬ — первая слева)
$btnPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$btnPanel.Dock = 'Fill'
$btnPanel.FlowDirection = 'LeftToRight'
$btnPanel.WrapContents = $true
$btnPanel.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 0)
$tbl.Controls.Add($btnPanel, 0, 2)

$btnApply = New-Object System.Windows.Forms.Button
$btnApply.Text = 'ПРИМЕНИТЬ'
$btnApply.Size = New-Object System.Drawing.Size(170, 34)
$btnApply.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$btnApply.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 212)
$btnApply.ForeColor = [System.Drawing.Color]::White
$btnApply.FlatStyle = 'Flat'

$btnAll = New-Object System.Windows.Forms.Button
$btnAll.Text = 'Выбрать всё'; $btnAll.Size = New-Object System.Drawing.Size(100, 34)
$btnAll.Add_Click({ foreach ($c in $checks) { $c.Checked = $true } })

$btnNone = New-Object System.Windows.Forms.Button
$btnNone.Text = 'Снять всё'; $btnNone.Size = New-Object System.Drawing.Size(100, 34)
$btnNone.Add_Click({ foreach ($c in $checks) { $c.Checked = $false } })

$btnRec = New-Object System.Windows.Forms.Button
$btnRec.Text = 'Рекомендуемые'; $btnRec.Size = New-Object System.Drawing.Size(115, 34)
$btnRec.Add_Click({ foreach ($c in $checks) { $c.Checked = [bool]$c.Tag.Default } })

$btnRevertAll = New-Object System.Windows.Forms.Button
$btnRevertAll.Text = 'Вернуть ВСЁ'; $btnRevertAll.Size = New-Object System.Drawing.Size(110, 34)

$rbOff = New-Object System.Windows.Forms.RadioButton
$rbOff.Text = 'Отключить'; $rbOff.Checked = $true; $rbOff.AutoSize = $true
$rbOff.Margin = New-Object System.Windows.Forms.Padding(10, 9, 0, 0)

$rbOn = New-Object System.Windows.Forms.RadioButton
$rbOn.Text = 'Вернуть обратно'; $rbOn.AutoSize = $true
$rbOn.Margin = New-Object System.Windows.Forms.Padding(6, 9, 0, 0)

$chkRestore = New-Object System.Windows.Forms.CheckBox
$chkRestore.Text = 'Точка восстановления'; $chkRestore.Checked = $true
$chkRestore.AutoSize = $true
$chkRestore.Margin = New-Object System.Windows.Forms.Padding(8, 9, 0, 0)

$btnPanel.Controls.Add($btnApply)
$btnPanel.Controls.Add($rbOff)
$btnPanel.Controls.Add($rbOn)
$btnPanel.Controls.Add($btnAll)
$btnPanel.Controls.Add($btnNone)
$btnPanel.Controls.Add($btnRec)
$btnPanel.Controls.Add($btnRevertAll)
$btnPanel.Controls.Add($chkRestore)

# Лог
$LogBox = New-Object System.Windows.Forms.TextBox
$LogBox.Multiline = $true; $LogBox.ReadOnly = $true; $LogBox.ScrollBars = 'Vertical'
$LogBox.Dock = 'Fill'
$LogBox.BackColor = [System.Drawing.Color]::FromArgb(24, 24, 24); $LogBox.ForeColor = [System.Drawing.Color]::LightGreen
$LogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$tbl.Controls.Add($LogBox, 0, 3)

# Переключение режима
$rbOn.Add_CheckedChanged({
    if ($rbOn.Checked) {
        $btnApply.Text = 'ВЕРНУТЬ ОБРАТНО'
        $btnApply.BackColor = [System.Drawing.Color]::FromArgb(16, 124, 16)
        $chkRestore.Enabled = $false
    } else {
        $btnApply.Text = 'ПРИМЕНИТЬ'
        $btnApply.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 212)
        $chkRestore.Enabled = $true
    }
})

# Применить / Вернуть выбранное
$btnApply.Add_Click({
    $sel = @($checks | Where-Object { $_.Checked })
    if ($sel.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Ничего не выбрано.'); return }
    $revert = $rbOn.Checked
    $verb = 'Применить'; if ($revert) { $verb = 'Вернуть обратно' }
    $ok = [System.Windows.Forms.MessageBox]::Show("${verb}: выбрано пунктов — $($sel.Count). Продолжить?", 'Подтверждение', 'YesNo', 'Question')
    if ($ok -ne 'Yes') { return }

    $btnApply.Enabled = $false; $btnRevertAll.Enabled = $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    if ((-not $revert) -and $chkRestore.Checked) { Log 'Создаю точку восстановления...'; New-RestorePoint }
    foreach ($c in $sel) {
        Log ">> $($c.Tag.Title)"
        try {
            if ($revert) { Revert-Title $c.Tag.Title }
            else { $script:CurTweak = $c.Tag.Title; & $c.Tag.Run }
        } catch { Log "  ОШИБКА: $($_.Exception.Message)" }
        finally { $script:CurTweak = $null; Save-DB }
    }
    Log 'ГОТОВО. Для полного эффекта перезагрузите ПК.'
    $form.Cursor = [System.Windows.Forms.Cursors]::Default
    $btnApply.Enabled = $true; $btnRevertAll.Enabled = $true
    $r = [System.Windows.Forms.MessageBox]::Show('Готово. Перезагрузить ПК сейчас?', 'Win11 Debloat', 'YesNo', 'Information')
    if ($r -eq 'Yes') { Restart-Computer -Force }
})

# Вернуть ВСЁ, что программа меняла
$btnRevertAll.Add_Click({
    $ok = [System.Windows.Forms.MessageBox]::Show('Вернуть ВСЕ изменения, сделанные программой?', 'Подтверждение', 'YesNo', 'Question')
    if ($ok -ne 'Yes') { return }
    $btnApply.Enabled = $false; $btnRevertAll.Enabled = $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    foreach ($title in @($script:DB.Keys)) {
        Log ">> $title"
        try { Revert-Title $title } catch { Log "  ОШИБКА: $($_.Exception.Message)" }
    }
    try { Revert-Legacy } catch { }
    Save-DB
    Log 'ВСЁ ВОЗВРАЩЕНО. Перезагрузите ПК.'
    $form.Cursor = [System.Windows.Forms.Cursors]::Default
    $btnApply.Enabled = $true; $btnRevertAll.Enabled = $true
})

Log 'Готов к работе. Выберите твики и режим, затем нажмите кнопку.'
[void]$form.ShowDialog()
