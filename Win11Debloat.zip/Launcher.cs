using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

[assembly: AssemblyTitle("Win11 Debloat")]
[assembly: AssemblyProduct("Win11 Debloat")]
[assembly: AssemblyVersion("1.0.0.0")]

static class Program
{
    [STAThread]
    static int Main()
    {
        string tmp = Path.Combine(Path.GetTempPath(), "Win11Debloat_" + Guid.NewGuid().ToString("N") + ".ps1");
        try
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("Win11Debloat.ps1"))
            using (StreamReader r = new StreamReader(s, Encoding.UTF8))
            {
                File.WriteAllText(tmp, r.ReadToEnd(), new UTF8Encoding(true));
            }

            ProcessStartInfo psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + tmp + "\"");
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            using (Process p = Process.Start(psi))
            {
                p.WaitForExit();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка запуска: " + ex.Message, "Win11 Debloat");
            return 1;
        }
        finally
        {
            try { File.Delete(tmp); } catch { }
        }
        return 0;
    }
}
