@echo off
chcp 65001 >nul
cd /d "%~dp0"
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (echo csc.exe not found & pause & exit /b 1)
"%CSC%" /nologo /codepage:65001 /target:winexe /out:Win11Debloat.exe /win32manifest:app.manifest /reference:System.Windows.Forms.dll /resource:Win11Debloat.ps1,Win11Debloat.ps1 Launcher.cs
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
echo.
echo Done: Win11Debloat.exe
pause
